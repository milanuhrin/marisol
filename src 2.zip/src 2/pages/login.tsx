import React from "react";
import Login from "Components/Login"; // Import the actual Login component

const LoginPage = () => {
  return <Login />;
};

export default LoginPage;